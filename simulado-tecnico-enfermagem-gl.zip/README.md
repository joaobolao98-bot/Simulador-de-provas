# Simulados - Técnico de Enfermagem

Banca: GL Consultoria. 7 simulados de 10 questões (70 no total), com correção imediata e explicação.

## Estrutura
- `index.html`: página principal
- `data/questoes.js`: banco de questões (edite aqui para adicionar)
- `assets/js/app.js`: lógica do simulador

Para criar um novo simulado, acrescente 10 questões ao final de `BANK` e um título em `TITLES`.
Publicação: Settings > Pages > Deploy from a branch > main > / (root).
