const FIXED = Math.floor(BANK.length / SIZE);
const DURATION = 50 * 60;

let curSim = 1, Q = [], cur = 0, answers = [], timer = null, timeLeft = DURATION;
const $ = id => document.getElementById(id);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

// Monta o menu
(function () {
  let h = "";
  for (let s = 1; s <= FIXED; s++) {
    h += `<button onclick="start(${s})" class="p-4 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-left cursor-pointer">
      <span class="font-bold text-blue-900 block">Simulado ${String(s).padStart(2, "0")}</span>
      <span class="text-xs text-blue-700">${TITLES[s - 1] || "Questões variadas"}</span></button>`;
  }
  h += `<button onclick="start(0)" class="p-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-left cursor-pointer">
      <span class="font-bold text-emerald-900 block">Simulado Aleatório</span>
      <span class="text-xs text-emerald-700">10 questões sorteadas de todo o banco (${BANK.length})</span></button>`;
  $("menu-grid").innerHTML = h;
})();

function start(sim) {
  curSim = sim;
  const raw = sim === 0 ? shuffle(BANK).slice(0, SIZE) : BANK.slice((sim - 1) * SIZE, sim * SIZE);
  // embaralha as alternativas de cada questão
  Q = raw.map(r => ({
    cat: r[0], q: r[1], exp: r[4],
    opts: shuffle([{ t: r[2], ok: true }, ...r[3].map(t => ({ t, ok: false }))])
  }));
  answers = Array(Q.length).fill(null);
  cur = 0; timeLeft = DURATION;
  $("menu").classList.add("hidden"); $("result").classList.add("hidden");
  $("quiz").classList.remove("hidden"); $("timer-box").classList.remove("hidden");
  $("sim-title").textContent = sim === 0 ? "Simulado Aleatório" : `Simulado ${String(sim).padStart(2, "0")} - ${TITLES[sim - 1] || ""}`;
  clearInterval(timer);
  timer = setInterval(tick, 1000); tick(true);
  render();
}

function tick(first) {
  if (!first) timeLeft--;
  if (timeLeft <= 0) { finish(); return; }
  const m = Math.floor(timeLeft / 60), s = timeLeft % 60;
  $("timer").textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function render() {
  const q = Q[cur], ans = answers[cur];
  $("tracker").textContent = `Questão ${cur + 1} de ${Q.length}`;
  $("cat").textContent = q.cat;
  $("qtext").textContent = q.q;
  $("bar").style.width = `${((cur + (ans !== null ? 1 : 0)) / Q.length) * 100}%`;

  const box = $("opts"); box.innerHTML = "";
  q.opts.forEach((o, i) => {
    const b = document.createElement("button");
    let cls = "w-full text-left p-4 rounded-lg border text-sm flex items-start gap-3 transition ";
    if (ans === null) cls += "border-slate-200 bg-white hover:bg-slate-50 cursor-pointer";
    else if (o.ok) cls += "border-emerald-500 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-500";
    else if (i === ans) cls += "border-rose-500 bg-rose-50 text-rose-900 ring-1 ring-rose-500";
    else cls += "border-slate-200 bg-white opacity-60";
    b.className = cls;
    const mark = ans === null ? "" : o.ok ? " ✔" : i === ans ? " ✘" : "";
    const lt = document.createElement("span"); lt.className = "font-semibold"; lt.textContent = String.fromCharCode(65 + i) + ")";
    const tx = document.createElement("span"); tx.className = "flex-grow"; tx.textContent = o.t + mark;
    b.append(lt, tx);
    if (ans === null) b.onclick = () => pick(i);
    else b.disabled = true;
    box.appendChild(b);
  });

  const ex = $("exp");
  if (ans === null) ex.classList.add("hidden");
  else {
    const right = q.opts[ans].ok;
    ex.className = "mt-5 p-4 rounded-lg border text-sm leading-relaxed " + (right ? "bg-emerald-50 border-emerald-200 text-emerald-900" : "bg-rose-50 border-rose-200 text-rose-900");
    const letter = String.fromCharCode(65 + q.opts.findIndex(o => o.ok));
    ex.textContent = (right ? "Correto! " : `Errado. A resposta certa é a letra ${letter}. `) + q.exp;
  }

  $("prev").disabled = cur === 0;
  const nb = $("next");
  const last = cur === Q.length - 1;
  nb.textContent = last ? "Finalizar" : "Próxima";
  nb.className = (last ? "bg-emerald-600 hover:bg-emerald-700" : "bg-blue-600 hover:bg-blue-700") + " text-white font-medium py-2.5 px-6 rounded-lg text-sm cursor-pointer";
}

function pick(i) { answers[cur] = i; render(); }
function go(d) {
  if (d > 0 && cur === Q.length - 1) { finish(); return; }
  cur = Math.max(0, Math.min(Q.length - 1, cur + d)); render();
}

function finish() {
  clearInterval(timer);
  $("quiz").classList.add("hidden"); $("timer-box").classList.add("hidden"); $("result").classList.remove("hidden");
  const hits = Q.filter((q, i) => answers[i] !== null && q.opts[answers[i]].ok).length;
  const pct = Math.round(hits / Q.length * 100);
  $("r-score").textContent = `${hits} / ${Q.length}`;
  $("r-pct").textContent = pct + "%";
  $("msg").textContent = pct >= 70 ? "Ótimo desempenho! Continue assim." : pct >= 50 ? "Bom caminho. Revise os erros abaixo." : "Vale revisar o conteúdo e refazer o simulado.";

  const rv = $("review"); rv.innerHTML = "";
  Q.forEach((q, i) => {
    const a = answers[i], ok = a !== null && q.opts[a].ok;
    const c = q.opts.find(o => o.ok).t;
    const d = document.createElement("div");
    d.className = "p-4 rounded-lg border text-sm space-y-1 " + (ok ? "bg-emerald-50 border-emerald-200" : "bg-rose-50 border-rose-200");
    const l1 = document.createElement("div"); l1.className = "font-semibold"; l1.textContent = `${i + 1}. ${q.q}`;
    const l2 = document.createElement("div"); l2.textContent = "Sua resposta: " + (a === null ? "não respondida" : q.opts[a].t);
    const l3 = document.createElement("div"); l3.textContent = "Resposta certa: " + c;
    const l4 = document.createElement("div"); l4.className = "text-slate-700"; l4.textContent = "Explicação: " + q.exp;
    d.append(l1, l2, l3, l4); rv.appendChild(d);
  });
}

function toMenu() {
  clearInterval(timer);
  ["quiz", "result", "timer-box"].forEach(id => $(id).classList.add("hidden"));
  $("menu").classList.remove("hidden");
}
