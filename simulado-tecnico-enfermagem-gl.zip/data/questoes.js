// Banco de questões - Técnico de Enfermagem - Banca GL Consultoria
// Formato: [categoria, enunciado, resposta certa, [3 erradas], explicação]
// A cada 10 questões seguidas forma 1 simulado automaticamente.
const P="Língua Portuguesa", M="Matemática e Raciocínio Lógico", E="Conhecimentos Específicos";
const BANK = [
// ---- Simulado 01: Fundamentos e Sinais Vitais
[P,"Em 'Vacine-se hoje!', predomina a função da linguagem:","Conativa (apelativa)",["Referencial","Emotiva","Poética"],"O texto procura levar o leitor a agir, característica da função conativa."],
[P,"Em 'Estou morrendo de fome', há a figura de linguagem:","Hipérbole",["Metáfora","Eufemismo","Ironia"],"A hipérbole exagera a ideia para dar ênfase."],
[M,"Um capital de R$ 1.000 aplicado a juros simples de 2% ao mês durante 5 meses rende de juros:","R$ 100",["R$ 10","R$ 110","R$ 200"],"J = C × i × t = 1.000 × 0,02 × 5 = 100."],
[M,"Em uma comunidade de 2.000 pessoas, 15% são crianças. Quantas são crianças?","300",["150","200","350"],"0,15 × 2.000 = 300."],
[E,"Os valores normais de frequência cardíaca de um adulto em repouso situam-se entre:","60 e 100 batimentos por minuto",["30 e 50 bpm","100 e 140 bpm","120 e 160 bpm"],"Abaixo de 60 é bradicardia; acima de 100, taquicardia."],
[E,"A frequência respiratória normal de um adulto em repouso é de:","12 a 20 incursões por minuto",["6 a 10","25 a 35","40 a 60"],"Acima de 20 é taquipneia; abaixo de 12, bradipneia."],
[E,"A saturação periférica de oxigênio (SpO₂) considerada normal em ar ambiente é, em geral:","95% ou mais",["85%","75%","60%"],"Valores baixos indicam hipoxemia e exigem avaliação imediata."],
[E,"A antissepsia é:","O uso de antissépticos na pele ou mucosas para reduzir microrganismos",["A esterilização de instrumentos cirúrgicos","A limpeza do piso","O uso de EPIs"],"Aplica-se a tecidos vivos; a esterilização se aplica a artigos."],
[E,"A higienização das mãos com água e sabão deve durar:","De 40 a 60 segundos",["5 a 10 segundos","10 a 15 segundos","2 a 3 minutos"],"Com preparação alcoólica, a fricção dura de 20 a 30 segundos."],
[E,"Para aferir o peso de um paciente adulto em balança, deve-se:","Usar balança calibrada e zerada, com o paciente de roupas leves e sem calçados",["Pesar com casaco e sapatos","Usar balança sem zerar","Estimar visualmente"],"Garante precisão, importante para cálculo de doses."],

// ---- Simulado 02: Administração de Medicamentos
[P,"Um folheto que ensina como prevenir a dengue é um texto predominantemente:","Injuntivo (instrucional)",["Narrativo","Poético","Descritivo"],"Orienta e instrui o leitor sobre como agir."],
[P,"A palavra 'infelizmente' é formada por:","Derivação prefixal e sufixal",["Composição por justaposição","Composição por aglutinação","Onomatopeia"],"in- (prefixo) + feliz + -mente (sufixo)."],
[M,"Se 3 agentes visitam 90 casas em 5 dias, 6 agentes visitam 180 casas em:","5 dias",["10 dias","2,5 dias","6 dias"],"Regra de três composta: dobrando agentes e casas, o prazo se mantém."],
[M,"As raízes da equação x² − 5x + 6 = 0 são:","2 e 3",["1 e 6","−2 e −3","5 e 6"],"Soma = 5 e produto = 6, logo as raízes são 2 e 3."],
[E,"Fazem parte dos 'certos' da administração de medicamentos:","Paciente, medicamento, dose, via e hora certos",["Paciente, diagnóstico e horário de visita","Médico, dose e laboratório","Somente dose e via"],"Há também registro, orientação e forma certos."],
[E,"Prescrição: 500 mg. Disponível: ampola de 250 mg em 2 mL. O volume a aspirar é:","4 mL",["2 mL","3 mL","1 mL"],"500 ÷ 250 = 2 ampolas; 2 × 2 mL = 4 mL."],
[E,"Prescrição de 600 mL de soro em 4 horas. O gotejamento em macrogotas é de:","50 gotas por minuto",["40 gotas/min","30 gotas/min","60 gotas/min"],"Gotas/min = volume ÷ (tempo em horas × 3) = 600 ÷ 12 = 50."],
[E,"A região indicada para injeção intramuscular por oferecer menor risco de lesão de nervos e vasos é:","A ventroglútea (de Hochstetter)",["A dorsoglútea","A face posterior do braço","A região plantar"],"É a mais segura para adultos, segundo a literatura da enfermagem."],
[E,"A via subcutânea é utilizada, por exemplo, para:","Insulina e heparina",["Nutrição parenteral total","Dietas enterais","Soros de grande volume"],"São pequenos volumes, de absorção lenta."],
[E,"Diante de um erro de medicação, o profissional deve:","Comunicar imediatamente a chefia e a equipe, observar o paciente e registrar o evento",["Ocultar para evitar punições","Corrigir sem avisar ninguém","Apagar o registro"],"A notificação protege o paciente e permite aprender com o erro."],

// ---- Simulado 03: Técnicas Básicas: Venóclise, Sondas e Oxigenoterapia
[P,"Em 'Os agentes visitaram as famílias', o sujeito é:","Simples: 'Os agentes'",["Oculto","Indeterminado","Inexistente"],"Está explícito e tem um só núcleo ('agentes')."],
[P,"Assinale a frase correta quanto à concordância:","Vendem-se casas nesse bairro.",["Vende-se casas nesse bairro.","Houveram muitas visitas ontem.","Fazem três anos que me mudei."],"Na voz passiva sintética o verbo concorda com o sujeito ('casas'); 'haver' e 'fazer' (tempo) são impessoais."],
[M,"Em um sorteio entre 20 famílias, 5 têm gestantes. A probabilidade de sortear uma família com gestante é:","1/4",["1/5","1/2","5/4"],"5/20 = 1/4."],
[M,"A média geométrica entre 4 e 9 é:","6",["6,5","13","36"],"√(4 × 9) = √36 = 6."],
[E,"Antes de uma punção venosa periférica, deve-se:","Higienizar as mãos, calçar luvas de procedimento e fazer antissepsia do local",["Dispensar as luvas","Puncionar sem antissepsia","Reencapar a agulha"],"Reduz o risco de infecção do acesso."],
[E,"São sinais de flebite:","Dor, calor, vermelhidão e edema ao longo da veia puncionada",["Palidez e frio no braço oposto","Tosse","Sudorese na testa"],"Se houver sinais, comunicar e retirar o acesso conforme protocolo."],
[E,"O método mais seguro para confirmar o posicionamento de sonda enteral antes de iniciar a dieta é:","A radiografia",["Apenas perguntar ao paciente","Observar a cor da pele","Soprar ar sem ausculta"],"A ausculta isolada não é considerada segura."],
[E,"Para prevenir infecção do trato urinário em paciente com sonda vesical de demora, deve-se:","Manter o sistema fechado e a bolsa coletora abaixo do nível da bexiga",["Desconectar a bolsa para facilitar a higiene","Apoiar a bolsa no chão","Elevar a bolsa acima da bexiga"],"Evita contaminação e refluxo de urina."],
[E,"Durante a oxigenoterapia, é correto:","Manter o ambiente livre de chamas e faíscas, pois o oxigênio favorece a combustão",["Permitir fumar no quarto","Usar óleo nas conexões","Dispensar prescrição"],"O oxigênio é tratado como medicamento e exige prescrição."],
[E,"Durante a administração de dieta enteral, o paciente deve permanecer:","Com a cabeceira elevada (30° a 45°)",["Deitado totalmente reto","Em posição de Trendelenburg","Com a cabeceira abaixada"],"Reduz o risco de refluxo e de aspiração."],

// ---- Simulado 04: Curativos, Úlceras por Pressão, IRAS e Biossegurança
[P,"Em 'A dengue é grave; portanto, é preciso prevenir', o conectivo 'portanto' indica:","Conclusão",["Oposição","Causa","Adição"],"Introduz a consequência do que foi afirmado antes."],
[P,"Na frase 'O ACS é o elo entre a comunidade e a equipe de saúde', a ideia central é:","O ACS faz a ligação entre a comunidade e a equipe",["O ACS substitui o médico","O ACS trabalha isolado","O ACS só cadastra famílias"],"'Elo' indica ligação entre as duas partes."],
[M,"O valor de sen 30° é:","1/2",["√3/2","√2/2","1"],"É um valor notável da trigonometria."],
[M,"Uma caixa d'água cúbica de 2 m de aresta tem volume de:","8 m³ (8.000 litros)",["4 m³","6 m³","16 m³"],"V = 2 × 2 × 2 = 8 m³; 1 m³ = 1.000 L."],
[E,"Na realização de curativos, a limpeza deve seguir a direção:","Da área mais limpa para a mais contaminada",["Da mais contaminada para a mais limpa","Aleatória","Sempre de baixo para cima"],"Evita contaminar a área limpa."],
[E,"Uma medida importante na prevenção de úlceras por pressão é:","Mudança de decúbito conforme o plano de cuidado (em geral, a cada 2 horas)",["Deixar o paciente na mesma posição","Massagear áreas ósseas com força","Usar lençóis com dobras"],"Também se avalia a pele e se alivia a pressão sobre proeminências ósseas."],
[E,"A úlcera por pressão em estágio 1 caracteriza-se por:","Pele íntegra com eritema que não desaparece à pressão",["Perda total da pele com osso exposto","Bolhas com secreção purulenta","Pele pálida e fria apenas"],"É o estágio inicial, em que a intervenção precoce evita a progressão."],
[E,"A principal medida para prevenir infecções relacionadas à assistência à saúde (IRAS) é:","A higienização das mãos",["Usar luvas em vez de lavar as mãos","Evitar o contato com o paciente","Usar o mesmo material em vários pacientes"],"Deve ser feita nos cinco momentos recomendados pela OMS."],
[E,"A NR-32 trata de:","Segurança e saúde no trabalho em serviços de saúde",["Segurança em minas","Trabalho em altura","Serviços de eletricidade"],"Prevê medidas contra riscos biológicos, químicos e físicos."],
[E,"Para proteção contra respingos de sangue e secreções, o conjunto de EPIs adequado inclui:","Luvas, avental, máscara e óculos de proteção",["Apenas touca","Apenas sapato fechado","Somente luvas"],"O tipo de EPI depende do risco da atividade."],

// ---- Simulado 05: Perfurocortantes e Central de Material (CME)
[P,"Assinale a frase em que há regência e crase corretas:","Chegamos ao posto de saúde às oito horas.",["Chegamos no posto de saúde às oito horas.","Chegamos ao posto de saúde as oito horas.","Chegamos em o posto de saúde às oito horas."],"'Chegar' pede a preposição 'a'; antes de hora feminina há crase."],
[P,"Assinale a frase em que a crase está correta:","Fui à unidade de saúde ontem.",["Fui à pé até a unidade.","Vou à visitar as famílias.","Refiro-me à elas."],"'À unidade' = a + a. Não há crase antes de palavra masculina, verbo ou pronome pessoal."],
[M,"A solução do sistema x + y = 12 e 2x + y = 20 é:","x = 8 e y = 4",["x = 4 e y = 8","x = 6 e y = 6","x = 10 e y = 2"],"Subtraindo as equações: x = 8; logo y = 4."],
[M,"O valor de 2³ × 2² é:","32",["16","64","10"],"Soma dos expoentes: 2⁵ = 32."],
[E,"Após acidente com material perfurocortante, a conduta imediata é:","Lavar o local com água e sabão, comunicar a chefia e buscar atendimento para avaliação e profilaxia",["Espremer o local até sangrar muito","Ignorar se o ferimento for pequeno","Esperar para comunicar no dia seguinte"],"Quanto antes a avaliação, melhor a eficácia da profilaxia."],
[E,"Quanto aos perfurocortantes, é correto:","Descartar em recipiente rígido e resistente, sem reencapar agulhas",["Reencapar a agulha com as duas mãos","Descartar em saco comum","Encher o coletor além do limite"],"Respeitar o limite de enchimento (2/3) do coletor."],
[E,"A RDC nº 15/2012 da ANVISA dispõe sobre:","Boas práticas para o processamento de produtos para saúde, como na CME",["Vigilância de alimentos","Registro de medicamentos","Controle de propaganda"],"Regula o funcionamento das Centrais de Material e Esterilização."],
[E,"O fluxo de trabalho na Central de Material e Esterilização (CME) deve ser:","Unidirecional, da área suja para a área limpa",["Livre, sem sentido definido","Da área limpa para a suja","Circular, com cruzamento de materiais"],"Evita a contaminação cruzada entre materiais sujos e estéreis."],
[E,"O monitoramento da esterilização com maior segurança é feito pelo indicador:","Biológico",["Apenas visual","De fita zebrada","De cor do invólucro"],"Usa esporos resistentes para provar a eficácia do processo."],
[E,"O indicador químico (como a fita de autoclave) informa que:","O pacote foi exposto ao processo, mas não comprova esterilização por si só",["O material está estéril com certeza absoluta","A autoclave está limpa","O produto não tem prazo de validade"],"É complementar ao indicador biológico."],

// ---- Simulado 06: Cirurgia Segura, Urgência e Emergência
[P,"Assinale a frase pontuada corretamente:","Maria, agente de saúde, visitou a casa.",["Maria agente, de saúde visitou a casa.","Maria, agente de saúde visitou, a casa.","Maria agente de saúde, visitou a casa."],"O aposto explicativo fica entre vírgulas."],
[P,"Assinale a grafia correta:","hipertensão",["hipertenção","ipertensão","hipertensaõ"],"A palavra deriva de 'tensão', com 's' e 'ão'."],
[M,"A razão entre 8 e 20, na forma simplificada, é:","2/5",["4/5","1/2","3/5"],"8/20 dividido por 4 = 2/5."],
[M,"Um produto de R$ 150 recebe desconto de 20%. O novo preço é:","R$ 120",["R$ 130","R$ 110","R$ 100"],"20% de 150 = 30; 150 − 30 = 120."],
[E,"O checklist de cirurgia segura da OMS é aplicado em três momentos:","Antes da indução anestésica, antes da incisão e antes de o paciente deixar a sala",["Apenas na alta","Somente após a cirurgia","Só antes da internação"],"Reduz erros como cirurgia no local ou paciente errado."],
[E,"No pós-operatório imediato, deve-se observar:","Sinais vitais, nível de consciência, dor, sangramentos e permeabilidade de drenos",["Apenas o apetite","Somente a cor do lençol","Nada, até a alta"],"A vigilância precoce detecta complicações."],
[E,"São sinais de alerta de AVC:","Desvio da boca, fraqueza em um lado do corpo e dificuldade para falar",["Dor de dente","Tosse seca","Coceira generalizada"],"É emergência: acionar imediatamente o atendimento (SAMU 192)."],
[E,"Nas compressões torácicas em adultos, segundo a AHA, a frequência e a profundidade recomendadas são:","100 a 120 por minuto e cerca de 5 cm (sem passar de 6 cm)",["60 por minuto e 2 cm","140 por minuto e 8 cm","80 por minuto e 1 cm"],"Permitir o retorno completo do tórax e minimizar interrupções."],
[E,"Em hemorragia externa, o primeiro cuidado é:","Realizar compressão direta no local com gaze ou pano limpo e acionar o socorro",["Retirar objetos cravados","Aplicar pó de café","Dar líquidos ao paciente"],"Se encharcar, sobrepor outro pano sem retirar o primeiro."],
[E,"Durante uma convulsão, deve-se:","Proteger a cabeça, afastar objetos e não colocar nada na boca",["Segurar a pessoa com força","Colocar uma colher na boca","Dar água"],"Após a crise, posicionar de lado e avaliar a respiração."],

// ---- Simulado 07: Saúde Pública, Ética e Registros
[P,"Em 'Se vacine; a proteção é de todos', temos como recurso de coesão:","O ponto e vírgula, que liga ideias relacionadas",["Um erro de pontuação","Um verbo auxiliar","Uma preposição"],"O ponto e vírgula separa orações com relação de sentido próxima."],
[P,"Assinale a palavra com acentuação correta:","farmácia",["farmacia","fármacia","farmácía"],"É paroxítona terminada em ditongo, e por isso leva acento."],
[M,"Se 4 agentes concluem um trabalho em 6 dias, 3 agentes, no mesmo ritmo, concluem em:","8 dias",["4,5 dias","9 dias","7 dias"],"Grandezas inversamente proporcionais: 4 × 6 = 3 × x, logo x = 8."],
[M,"Sendo f(x) = 2x + 3, o valor de f(4) é:","11",["8","14","9"],"2 × 4 + 3 = 11."],
[E,"Na Rede de Frio do Programa Nacional de Imunizações, as vacinas devem ser mantidas, em geral, entre:","+2 °C e +8 °C",["−10 °C e 0 °C","+15 °C e +25 °C","+30 °C e +40 °C"],"A temperatura é monitorada e registrada diariamente."],
[E,"Segundo o ECA, a suspeita de maus-tratos contra criança ou adolescente deve ser:","Obrigatoriamente comunicada ao Conselho Tutelar",["Mantida em sigilo da rede","Comunicada apenas se confirmada por perícia","Ignorada se a família negar"],"A comunicação é dever legal dos profissionais de saúde."],
[E,"O exame preventivo do câncer do colo do útero (Papanicolau) é indicado, em geral, para mulheres de:","25 a 64 anos que já iniciaram a vida sexual",["10 a 15 anos","70 a 90 anos apenas","Qualquer idade, só se houver sintomas"],"Segue a recomendação do Ministério da Saúde."],
[E,"O teste rápido para HIV oferecido no SUS deve ser acompanhado de:","Aconselhamento e garantia de confidencialidade",["Divulgação do resultado à família","Cobrança de taxa","Isolamento do paciente"],"O resultado reagente exige confirmação e encaminhamento ao serviço."],
[E,"Segundo o Código de Ética dos Profissionais de Enfermagem (Resolução COFEN nº 564/2017), é dever do profissional:","Guardar sigilo sobre as informações do paciente, salvo nos casos previstos em lei",["Divulgar casos nas redes sociais","Executar atos para os quais não está habilitado","Omitir erros da equipe"],"O sigilo protege a dignidade e a privacidade do paciente."],
[E,"O registro de enfermagem no prontuário deve ser:","Claro, legível, completo, com data, hora, assinatura e identificação do profissional",["Feito a lápis","Corrigido com corretivo","Sem identificação"],"É documento legal e instrumento de comunicação da equipe."]
];

const SIZE = 10;
const TITLES = ["Fundamentos e Sinais Vitais", "Administração de Medicamentos", "Técnicas Básicas: Venóclise, Sondas e Oxigenoterapia", "Curativos, Úlceras por Pressão, IRAS e Biossegurança", "Perfurocortantes e Central de Material (CME)", "Cirurgia Segura, Urgência e Emergência", "Saúde Pública, Ética e Registros"];
